package com.example.aarav

import  android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class LoginActivity : AppCompatActivity() {

    lateinit var etMob: EditText
    lateinit var etPass: EditText
    lateinit var txtForgot2: TextView
    lateinit var txtReg: TextView
    lateinit var btnLog: Button
    val validMobileNumber = "1234567890"
    val validPassword = arrayOf("aarav1", "panther", "widwo", "tony", "thanos", "aarav","ruchira")
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences =
            getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)

        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
        setContentView(R.layout.activity_login)

        if (isLoggedIn) {
            val intent = Intent(this@LoginActivity, AvengersActivity::class.java)
            startActivity(intent)

        }



        title = "LOG IN"

        etMob = findViewById(R.id.etMob)
        etPass = findViewById(R.id.etPass)
        btnLog = findViewById(R.id.btnLog)
        txtForgot2 = findViewById(R.id.txtForgot2)
        txtReg = findViewById(R.id.txtReg)


        btnLog.setOnClickListener {
            val mobilenumber = etMob.text.toString()
            val password = etPass.text.toString()

            var nameofavenger = "Avenger"
            val intent = Intent(this@LoginActivity, AvengersActivity::class.java)

            if ((mobilenumber == validMobileNumber)) {
                if (password == validPassword[0]) {

                    nameofavenger = "Avenger Aarav"
                    savePreferences(nameofavenger)
                    startActivity(intent)

                } else if (password == validPassword[1]) {

                    nameofavenger = "Black Panther"

                    savePreferences(nameofavenger)
                    startActivity(intent)

                } else if (password == validPassword[2]) {

                    nameofavenger = "Widow"
                    savePreferences(nameofavenger)

                    startActivity(intent)

                } else if (password == validPassword[3]) {

                    nameofavenger = "Ironman"
                    savePreferences(nameofavenger)

                    startActivity(intent)

                } else if (password == validPassword[4]) {

                    nameofavenger = "Avenger"
                    savePreferences(nameofavenger)

                    startActivity(intent)
                } else if (password == validPassword[5]) {

                    nameofavenger = "AARAV"
                    savePreferences(nameofavenger)

                    startActivity(intent)
                }
                else if (password == validPassword[6]) {

                    nameofavenger = "Ruchira"
                    savePreferences(nameofavenger)

                    startActivity(intent)
                }
            } else {
                Toast.makeText(
                    this@LoginActivity,
                    "Access denied by Aarav",
                    Toast.LENGTH_LONG
                ).show()
            }

        }
    }


    override fun onPause() {
        super.onPause()
        finish()
    }

    fun savePreferences(title: String) {
        sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
        sharedPreferences.edit().putString("Title", title).apply()
    }
}

